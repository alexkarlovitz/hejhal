typedef struct {double x,y;} complex;

complex add(), sub(), mult(), cdiv(), recip(); 
complex cxsqrt(), contsqrt(), polar();
double cxabs(), arg();
